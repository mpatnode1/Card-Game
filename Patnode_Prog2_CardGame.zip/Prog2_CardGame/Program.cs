﻿namespace Prog2_CardGame
{
    internal class Program
    {
        static void Main()
        {
            new Menu();
            
        }
    }
}
